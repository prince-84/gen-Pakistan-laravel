<header class="w-full sticky top-0 z-50 shadow-sm bg-white/95 backdrop-blur-md border-b border-slate-200" id="headerContainer">
    <!-- Top Bar -->
    <div class="bg-corporate-primary text-slate-300 py-2 px-4 text-center text-xs font-medium tracking-wide border-b border-slate-800">
        <p>An Affiliate of the Global Entrepreneurship Network</p>
    </div>

    <!-- Main Navigation -->
    <div class="bg-transparent">
        <div class="container-custom py-4 flex items-center justify-between">
            <!-- Logo -->
            <a href="/" class="flex items-center group py-2">
                <img src="/images/gen_logo.png" alt="GEN Pakistan Logo" class="h-16 w-auto object-contain" />
            </a>

            <!-- Desktop Nav -->
            <nav class="hidden lg:flex items-center gap-8">
                <!-- About Menu -->
                <div class="relative group/nav py-6 -my-6">
                    <a href="#" class="text-sm font-semibold text-slate-600 group-hover/nav:text-corporate-accent flex items-center gap-1.5 uppercase tracking-wide transition-colors duration-300">
                        About
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="opacity-50 group-hover/nav:opacity-100 transition-opacity duration-300">
                            <path d="m6 9 6 6 6-6" />
                        </svg>
                    </a>
                    
                    <div class="absolute top-[100%] left-1/2 -translate-x-[30%] w-max bg-white border border-slate-200 border-t-0 rounded-b-xl shadow-xl opacity-0 invisible group-hover/nav:opacity-100 group-hover/nav:visible transition-all duration-300 z-50">
                        <div class="flex p-8 gap-8">
                            <!-- GLOBAL -->
                            <div class="w-[220px] flex flex-col">
                                <h3 class="text-[11px] font-bold text-slate-400 tracking-[0.15em] uppercase mb-5 h-4">GLOBAL</h3>
                                <div class="flex flex-col gap-6">
                                    <a href="/about" class="group/item block">
                                        <h4 class="text-[15px] font-bold text-slate-800 group-hover/item:text-corporate-accent mb-1.5 transition-colors duration-300">About GEN</h4>
                                        <p class="text-[13px] text-slate-500 leading-relaxed">Operating in 200 countries to make it easier for anyone to start and scale.</p>
                                    </a>
                                    <a href="/board-staff" class="group/item block">
                                        <h4 class="text-[15px] font-bold text-slate-800 group-hover/item:text-corporate-accent mb-1.5 transition-colors duration-300">Board + Staff</h4>
                                        <p class="text-[13px] text-slate-500 leading-relaxed">Leading the strategic direction and daily execution of the GEN mission.</p>
                                    </a>
                                    <a href="/partners" class="group/item block">
                                        <h4 class="text-[15px] font-bold text-slate-800 group-hover/item:text-corporate-accent mb-1.5 transition-colors duration-300">Our Partners</h4>